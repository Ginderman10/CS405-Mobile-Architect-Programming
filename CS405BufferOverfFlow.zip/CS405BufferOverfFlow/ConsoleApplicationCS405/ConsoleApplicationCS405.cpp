// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
	

	std::cout << "Buffer Overflow Example" << std::endl;

	// TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
	//  even though it is a constant and the compiler buffer overflow checks are on.
	//  You need to modify this method to prevent buffer overflow without changing the account_order
	//  varaible, and its position in the declaration. It must always be directly before the variable used for input.

	const std::string account_number = "CharlieBrown42";
	char user_input[20];  
	int origionalSize = std::size(user_input);   //length of the array of characters
	std::string userTypedInput;   //string to hold the users input.
	

	std::cout << "Enter a value: ";
	
	std::cin >> userTypedInput;  // input stream for the users input and put its size into a variable
	int sizeOfInput = std::size(userTypedInput);
	


	//checks size of entered input vs origional size of the character array, and if less than or equal to then print out input and account number.
	if (sizeOfInput <= origionalSize)
	{
		std::cout << "Input is valid" << std::endl;
		strcpy_s(user_input, userTypedInput.c_str());
		std::cout << "You entered: " << user_input << std::endl;
		std::cout << "Account Number = " << account_number << std::endl;

	}
	//if not than give overflow buffer error.
	else
	{
		std::cout << "Warning Overflow Detected";
	}

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu